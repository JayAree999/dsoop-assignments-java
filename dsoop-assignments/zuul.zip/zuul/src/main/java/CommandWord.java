public enum CommandWord
{
    GO,HELP,QUIT,UNKNOWN,LOOK,BACK;
}
